# html-css-sencillo
Código de una página web muy sencilla creada con HTML y CSS. 
<hr>
<h5>Espero les resulte de utilidad</h5>

<h2 style="text-align:center">Si quieres ir desde 0 a 100 en el <strong>Desarrollo Web FullStack</strong> - (Front-End y Back-End): Aquí te dejo una ruta que te prepare:</h2>
<table>
  <tr>
    <td>
      <a href="https://cedavilu.com/curso-desarrollo-web-detalle.html" target="_blank"> <img src="https://cedavilu.com/assets/img/cursos/cursos-1.png" > </a>      
    </td>
    <td>
       <a href="https://cedavilu.com/curso-javascript-detalle.html" target="_blank"><img style="width:25" src="https://cedavilu.com/assets/img/cursos/cursos-2.png" ></a>      
    </td>
    <td>
      <a href= "https://cedavilu.com/curso-javascript-avanzado-detalle.html" target="_blank"><img style="width:25" src="https://cedavilu.com/assets/img/cursos/cursos-3.png" ></a>
    </td>
    <td>
    <a href="https://cedavilu.com/curso-nodejs-detalle.html" target="_blank"> <img style="width:25" src="https://cedavilu.com/assets/img/cursos/cursos-4.png" ></a>
    </td>
  </tr>
</table>

<table>
  <tr>  
    <td>
       <a href= "https://cedavilu.com/" target="_blank"> <img style="width: 100" src="https://adanielf.files.wordpress.com/2020/04/frase-daniel-fuentes.jpg"></a>
    </td> 
  </tr>
</table>
